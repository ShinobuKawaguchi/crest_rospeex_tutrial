#!/usr/bin/env python
# -*- coding: utf-8 -*-
 
import ConfigParser
import os
import os.path
import rospy

SS_TEXT = '../config/ss_text.def'
 
# Import other libraries
from rospeex_if import ROSpeexInterface
 
class ChkSS(object):
    def __init__(self):
        self._interface = None
        self._ss_text = []
        self._timestamp = 0
 
    def load_ss_text(self):
        try:
            if not os.path.exists(SS_TEXT):
                rospy.logerr( 'not exist ' + SS_TEXT )

            timestamp = os.stat( SS_TEXT ).st_mtime
            if timestamp != self._timestamp:
                self._timestamp = timestamp
                rospy.loginfo( 'timestamp : ' + str( self._timestamp ) )

                self._ss_text = []
                conf = ConfigParser.SafeConfigParser()
                conf.read(SS_TEXT)

                for s in conf.sections():
                    self._ss_text.append( conf.get(s, 'Text') )

                return True

        except  Exception as err:
            rospy.logerr( err )

        return False
 
    def run(self):
        # initialize ros node
        rospy.init_node('chk_ss', anonymous=True)
 
        # initialize rospeex
        self._interface = ROSpeexInterface()
        self._interface.init()

        r = rospy.Rate(1)
        rospy.sleep(5)
        while not rospy.is_shutdown():
            if self.load_ss_text():
                for text in self._ss_text:
                    self._interface.say(text, 'ja', 'nict')
                    rospy.sleep(2)
            r.sleep()
        
 
if __name__ == '__main__':
    try:
        node = ChkSS()
        node.run()
    except rospy.ROSInterruptException:
        pass
