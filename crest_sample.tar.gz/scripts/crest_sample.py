#!/usr/bin/env python
# -*- coding: utf-8 -*-
 
import rospy
import scenario

# Import other libraries
from rospeex_if import ROSpeexInterface
 
class Sample(object):
    def __init__(self):
        self._interface = None
        self._scenario = None
 
    def sr_response(self, message):
        # check speech recognition response text
        res = self._scenario.judge(message)

        if len(res) > 0:
            # rospeex reply
            self._interface.say(res, 'ja', 'nict')
 
    def run(self):
        # initialize ros node
        rospy.init_node('crest_sample', anonymous=True)
 
        # initialize rospeex
        self._interface = ROSpeexInterface()
        self._interface.init()
        self._interface.register_sr_response(self.sr_response)
        self._interface.set_spi_config(language='ja', engine='nict')

        # initialize scenario
        self._scenario = scenario.DialogueScenario()

        rospy.spin()
 
if __name__ == '__main__':
    try:
        node = Sample()
        node.run()
    except rospy.ROSInterruptException:
        pass
