#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ConfigParser
import datetime
import os
import os.path
import re
import rospy

SCENARIO_DEF = '../config/SimpleScenario.def'


class DialogueScenario():
    def __init__(self):

        self._human = []
        self._robot = []
        self._cmd = []

        self._no_match_robot = None
        self._no_match_cmd = None

        try:
            rospy.loginfo( '### dir : ' + os.getcwd() )

            if not os.path.exists(SCENARIO_DEF):
                rospy.logerr( 'not exist ' + SCENARIO_DEF )

            myScenario = ConfigParser.SafeConfigParser()
            myScenario.read(SCENARIO_DEF)

            for s in myScenario.sections():

                rospy.loginfo( 'Section : ' + s )

                human = myScenario.get(s, 'Human')
                rospy.loginfo( 'human : ' + human )

                robot = myScenario.get(s, 'Robot')
                rospy.loginfo( 'robot : ' + robot )
                cmd = myScenario.get(s, 'Command')
                rospy.loginfo( 'cmd : ' + cmd )

                if len(human) > 0:
                    r = re.compile(human)
                    self._human.append(r)
                    self._robot.append(robot)
                    self._cmd.append(cmd)

                else:
                    self._no_match_robot = robot
                    self._no_match_cmd = cmd

        except Exception as Err:
            rospy.logerr( Err )

    def judge(self, msg):

        rospy.loginfo( 'judge \"' + msg + '\"' )

        ret = []
        cmd = None
        robot = None

        for i, r in enumerate(self._human):

            m = r.search(msg)
            if m is not None:
                rospy.loginfo( 'Match' )
                robot = self._robot[i]
                cmd = self._cmd[i]
                break

        if robot is None and self._no_match_robot is not None:
            robot = self._no_match_robot
            cmd = self._no_match_cmd

        if robot is not None:
            rospy.loginfo( 'robot : ' + robot )
        else:
            robot = u'エラーです。'

        if cmd is not None and len(cmd) > 0:
            rospy.loginfo( 'cmd : ' + cmd )
            try:
                robot = self.exec_cmd( cmd, robot )
            except Exception as err:
                rospy.logerr( err )
                raise

            rospy.loginfo( 'robot : ' + robot )

        return robot

    def exec_cmd(self, cmd, addition):
        res = addition

        if cmd == 'talking_watch':
            d = datetime.datetime.today()
            res =  addition + '%d時%d分です。'%(d.hour, d.minute)

        return res

